#ifndef TEAR_H
 #define TEAR_H

#include <stdint.h> 
// extern uint16_t tear_0[20400];
// extern const int tear_0_width;
// extern const int tear_0_height;

// extern uint16_t tear_1[20400];
// extern const int tear_1_width;
// extern const int tear_1_height;

// extern uint16_t tear_2[20400];
// extern const int tear_2_width;
// extern const int tear_2_height;

// extern uint16_t tear_3[20400];
// extern const int tear_3_width;
// extern const int tear_3_height;

// extern uint16_t tear_4[20400];
// extern const int tear_4_width;
// extern const int tear_4_height;

#endif //TEARS_H 
 