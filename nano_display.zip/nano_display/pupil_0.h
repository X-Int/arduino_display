#ifndef PUPIL_0_H
#define PUPIL_0_H 

#include <stdint.h> 

extern uint16_t pupil_0[57600];
extern const int pupil_0_width;
extern const int pupil_0_height;

#endif // {filename.upper()}_H
